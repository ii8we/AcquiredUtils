package dev.bobodado.acquiredutils.client.gui.widget;

import dev.bobodado.acquiredutils.client.gui.theme.Theme;
import java.util.function.Consumer;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_357;

public class ValueSliderWidget extends class_357 {

    private final double min;
    private final double max;
    private final double step;
    private final boolean percentage;
    private final String suffix;
    private final Consumer<Float> onChange;
    private final Runnable onReleaseAction;

    public ValueSliderWidget(int x, int y, int width, int height, float initialValue,
                             float min, float max, float step, boolean percentage,
                             String suffix, Consumer<Float> onChange, Runnable onReleaseAction) {
        super(x, y, width, height, class_2561.method_43473(), normalize(initialValue, min, max));
        this.min = min; this.max = max; this.step = step; this.percentage = percentage;
        this.suffix = suffix; this.onChange = onChange; this.onReleaseAction = onReleaseAction;
        snapToStep(); method_25346();
    }

    public ValueSliderWidget(int x, int y, int width, int height, float initialValue,
                             float min, float max, float step, boolean percentage,
                             String suffix, Consumer<Float> onChange) {
        this(x, y, width, height, initialValue, min, max, step, percentage, suffix, onChange, () -> {});
    }

    private static double normalize(double value, double min, double max) {
        double clamped = Math.max(min, Math.min(max, value));
        return (clamped - min) / (max - min);
    }

    private double currentValue() { return min + this.field_22753 * (max - min); }

    private void snapToStep() {
        double raw = currentValue();
        double snapped = Math.round((raw - min) / step) * step + min;
        snapped = Math.max(min, Math.min(max, snapped));
        this.field_22753 = normalize(snapped, min, max);
    }

    private String formatValue() {
        double current = currentValue();
        if (percentage) return String.format("%.0f%%", current * 100.0);
        if (step >= 1.0) return String.format("%.0f%s", current, suffix);
        if (step >= 0.1) return String.format("%.1f%s", current, suffix);
        return String.format("%.2f%s", current, suffix);
    }

    @Override public void method_25357(class_11909 event) {
        snapToStep(); method_25346(); method_25344(); onReleaseAction.run(); super.method_25357(event);
    }

    @Override protected void method_25346() { method_25355(class_2561.method_43470(formatValue())); }

    @Override protected void method_25344() { snapToStep(); onChange.accept((float) currentValue()); method_25346(); }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        Theme theme = Theme.current();
        class_310 minecraft = class_310.method_1551();

        int cy = method_46427() + field_22759 / 2 + sOffset(0);
        int left = method_46426() + 3;
        int right = method_46426() + field_22758 - 3;
        int trackH = Math.max(4, Math.min(6, field_22759 / 3));
        int trackY = cy - trackH / 2;

        // Dark rail with a purple fill. The value is intentionally not drawn
        // over the rail anymore, which keeps the slider readable at low resolutions.
        graphics.method_25294(
            left,
            trackY,
            right,
            trackY + trackH,
            theme.sliderTrack
        );

        int fillRight = left + (int) ((right - left) * this.field_22753);
        if (fillRight > left) {
            graphics.method_25294(
                left,
                trackY,
                fillRight,
                trackY + trackH,
                theme.accent
            );
            graphics.method_25294(
                left,
                trackY,
                fillRight,
                trackY + 1,
                theme.accentBright
            );
        }

        // Small gold diamond thumb.
        int cx = Math.max(left, Math.min(right, fillRight));
        int r = Math.max(4, Math.min(6, field_22759 / 3));
        int gold = isSliderHighlighted() ? 0xFFFFE4A6 : 0xFFE5B85C;

        for (int dy = -r; dy <= r; dy++) {
            int span = r - Math.abs(dy);
            graphics.method_25294(
                cx - span,
                cy + dy,
                cx + span + 1,
                cy + dy + 1,
                gold
            );
        }
        graphics.method_25294(
            cx - 1,
            cy - r + 2,
            cx + 2,
            cy + r - 1,
            theme.accent
        );

        // Compact value badge sits above the thumb instead of in the track.
        class_2561 message = method_25369();
        int valueW = Math.max(sOffset(34), minecraft.field_1772.method_27525(message) + 6);
        int valueH = Math.max(sOffset(12), 12);
        int valueX = Math.max(
            method_46426(),
            Math.min(method_46426() + field_22758 - valueW, cx - valueW / 2)
        );
        int valueY = Math.max(method_46427(), trackY - valueH - 2);

        graphics.method_25294(
            valueX,
            valueY,
            valueX + valueW,
            valueY + valueH,
            0xD9150D20
        );
        graphics.method_73198(
            valueX,
            valueY,
            valueW,
            valueH,
            theme.frameMid
        );
        graphics.method_51439(
            minecraft.field_1772,
            message,
            valueX + (valueW - minecraft.field_1772.method_27525(message)) / 2,
            valueY + 2,
            theme.text,
            false
        );
    }

    private int sOffset(int base) {
        return Math.max(1, base);
    }

    private boolean isSliderHighlighted() {
        return method_49606() || method_25370();
    }

}
