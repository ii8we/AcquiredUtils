package dev.bobodado.acquiredutils.client.gui.widget;

import dev.bobodado.acquiredutils.client.gui.theme.Theme;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6381;
import net.minecraft.class_6382;

public class ThemedButtonWidget extends class_339 {

    private final Runnable clickHandler;
    private final boolean bold;

    public ThemedButtonWidget(int x, int y, int width, int height, class_2561 label, Runnable clickHandler) {
        this(x, y, width, height, label, clickHandler, false);
    }

    public ThemedButtonWidget(int x, int y, int width, int height, class_2561 label, Runnable clickHandler, boolean bold) {
        super(x, y, width, height, label);
        this.clickHandler = clickHandler;
        this.bold = bold;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        Theme theme = Theme.current();
        boolean hovered = method_49606();
        boolean pressed = method_25370();

        int outer = hovered ? theme.accentBright : theme.frameMid;
        int inner = hovered ? theme.accent : theme.frameAccent;
        int top = hovered ? theme.headerTop : theme.sidebarBottom;
        int bottom = pressed ? theme.panelTop : theme.buttonBottom;

        graphics.method_25296(
            method_46426(), method_46427(), method_46426() + field_22758, method_46427() + field_22759,
            top, bottom
        );

        graphics.method_73198(method_46426(), method_46427(), field_22758, field_22759, outer);
        if (field_22758 > 4 && field_22759 > 4) {
            graphics.method_73198(
                method_46426() + 1, method_46427() + 1, field_22758 - 2, field_22759 - 2, inner
            );
        }

        if (hovered) {
            graphics.method_25294(
                method_46426() + 2, method_46427() + 2, method_46426() + 3, method_46427() + field_22759 - 2,
                theme.accentBright
            );
        }

        var font = class_310.method_1551().field_1772;
        class_2561 text = bold
            ? method_25369().method_27661().method_27696(class_2583.field_24360.method_10982(true))
            : method_25369();

        int textWidth = font.method_27525(text);
        graphics.method_51439(
            font, text,
            method_46426() + (field_22758 - textWidth) / 2,
            method_46427() + (field_22759 - 8) / 2,
            hovered ? theme.accentBright : theme.text,
            false
        );
    }

    @Override
    public void method_25348(class_11909 event, boolean doubleClick) {
        clickHandler.run();
    }

    @Override
    public void method_47399(class_6382 output) {
        output.method_37034(class_6381.field_33788, method_25369());
    }
}
