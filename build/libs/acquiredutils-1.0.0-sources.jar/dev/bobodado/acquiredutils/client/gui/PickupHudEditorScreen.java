package dev.bobodado.acquiredutils.client.gui;

import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import dev.bobodado.acquiredutils.client.gui.theme.Theme;
import dev.bobodado.acquiredutils.client.gui.widget.ThemedButtonWidget;

public class PickupHudEditorScreen extends class_437 {

    private static final int PREVIEW_COLOR = 0xFFE0C7FF;

    private final class_437 parent;
    private boolean dragging;

    public PickupHudEditorScreen(class_437 parent) {
        super(class_2561.method_43471("acquiredutils.gui.edit_hud.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        method_37063(new ThemedButtonWidget(
            this.field_22789 / 2 - 50,
            this.field_22790 - 35,
            100,
            20,
            class_2561.method_43471("gui.done"),
            this::method_25419
        ));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        Theme theme = Theme.current();

        // Keep the world visible behind the editor while adding a light purple tint.
        graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0x700B0712);

        class_2561 title = class_2561.method_43471("acquiredutils.gui.edit_hud.title");
        int titleWidth = this.field_22793.method_27525(title);
        graphics.method_51439(this.field_22793, title, (this.field_22789 - titleWidth) / 2, 15, theme.text, true);

        class_2561 hint = class_2561.method_43471("acquiredutils.gui.edit_hud.hint");
        int hintWidth = this.field_22793.method_27525(hint);
        graphics.method_51439(this.field_22793, hint, (this.field_22789 - hintWidth) / 2, 30, theme.credit, false);

        AcquiredUtilsConfig cfg = AcquiredUtilsConfig.get();
        int x = Math.round(cfg.notificationPositionX * this.field_22789);
        int y = Math.round(cfg.notificationPositionY * this.field_22790);
        String preview = "3x Shard";
        int previewWidth = this.field_22793.method_1727(preview);
        int anchorX = x;
        int drawX;

        if (cfg.notificationPositionX < 0.5f) {
            drawX = anchorX;
        } else if (cfg.notificationPositionX > 0.5f) {
            drawX = anchorX - previewWidth;
        } else {
            drawX = anchorX - previewWidth / 2;
        }

        graphics.method_25294(drawX - 5, y - 4, drawX + previewWidth + 5, y + 12, 0x66000000);
        graphics.method_25294(drawX - 2, y - 6, drawX, y + 14, theme.accent);
        graphics.method_51439(this.field_22793, class_2561.method_43470(preview), drawX, y, PREVIEW_COLOR, true);

        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        // Let normal widgets (especially the Done button) receive the click first.
        if (super.method_25402(event, doubleClick)) {
            return true;
        }

        if (event.method_74245() == 0) {
            dragging = true;
            updatePosition(event.comp_4798(), event.comp_4799());
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25406(class_11909 event) {
        if (super.method_25406(event)) {
            dragging = false;
            return true;
        }

        if (event.method_74245() == 0) {
            dragging = false;
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        if (super.method_25403(event, dragX, dragY)) {
            return true;
        }

        if (dragging) {
            updatePosition(event.comp_4798(), event.comp_4799());
            return true;
        }

        return false;
    }

    private void updatePosition(double mouseX, double mouseY) {
        AcquiredUtilsConfig cfg = AcquiredUtilsConfig.get();
        cfg.notificationPositionX = (float) Math.max(0.0, Math.min(1.0, mouseX / this.field_22789));
        cfg.notificationPositionY = (float) Math.max(0.0, Math.min(1.0, mouseY / this.field_22790));
        cfg.markDirty();
    }

    @Override
    public void method_25419() {
        AcquiredUtilsConfig.saveIfDirty();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }
}
