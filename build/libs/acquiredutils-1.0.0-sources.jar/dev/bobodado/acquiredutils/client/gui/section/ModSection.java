package dev.bobodado.acquiredutils.client.gui.section;

import dev.bobodado.acquiredutils.client.gui.AcquiredUtilsConfigScreen;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;

public abstract class ModSection {

    protected final AcquiredUtilsConfigScreen screen;

    public ModSection(AcquiredUtilsConfigScreen screen) {
        this.screen = screen;
    }

    public abstract String getId();

    public abstract class_2561 getDisplayName();

    public List<GuiRow> getRows() {
        return Collections.emptyList();
    }

    protected int s(int base) {
        return screen.s(base);
    }

    protected float scale() {
        return screen.getMenuScale();
    }

    protected <T extends class_339> T addWidget(T widget) {
        screen.addSectionWidget(widget);
        return widget;
    }

    public void render(class_332 graphics, int mouseX, int mouseY, float partialTick,
                       int contentX, int contentY, int contentWidth, int contentHeight) {
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        return false;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return false;
    }

    public void onClose() {
    }
}