package dev.bobodado.acquiredutils.client.gui.widget;

import dev.bobodado.acquiredutils.client.gui.theme.Theme;
import java.util.function.Consumer;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import java.util.function.BooleanSupplier;

public final class ThemedCheckboxWidget extends class_339 {

    private final BooleanSupplier getter;
    private final Consumer<Boolean> setter;

    public ThemedCheckboxWidget(int x, int y, int width, int height,
                                BooleanSupplier getter, Consumer<Boolean> setter) {
        super(x, y, width, height, class_2561.method_43473());
        this.getter = getter;
        this.setter = setter;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        Theme theme = Theme.current();
        int size = Math.min(12, Math.max(10, field_22759 - 4));
        int x = method_46426() + (field_22758 - size) / 2;
        int y = method_46427() + (field_22759 - size) / 2 - 2;

        int fill = getter.getAsBoolean() ? theme.accent : theme.footerBottom;
        int border = method_49606() ? theme.accentBright : theme.frameMid;

        graphics.method_25294(x, y, x + size, y + size, fill);
        graphics.method_73198(x, y, size, size, border);

        if (getter.getAsBoolean()) {
            graphics.method_51439(
                net.minecraft.class_310.method_1551().field_1772,
                class_2561.method_43470("✓"),
                x + 2,
                y + 1,
                theme.text,
                false
            );
        }
    }

    @Override
    public void method_25348(class_11909 event, boolean doubleClick) {
        setter.accept(!getter.getAsBoolean());
    }

    @Override
    public void method_47399(class_6382 output) {
        output.method_37034(class_6381.field_33788, class_2561.method_43471("acquiredutils.gui.checkbox.toggle"));
    }
}
