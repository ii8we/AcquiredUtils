package dev.bobodado.acquiredutils.client.gui.widget;

import dev.bobodado.acquiredutils.client.gui.theme.Theme;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6381;
import net.minecraft.class_6382;

/** Compact themed checkbox matching the Slot Lock control. */
public final class ThemedCheckboxWidget extends class_339 {
    private static final int SIZE = 12;
    private static final class_2960 CHECKED = class_2960.method_60655(
        "acquiredutils", "textures/gui/checkbox_purple_checked.png"
    );
    private static final class_2960 UNCHECKED = class_2960.method_60655(
        "acquiredutils", "textures/gui/checkbox_purple_unchecked.png"
    );

    private final BooleanSupplier getter;
    private final Consumer<Boolean> setter;

    public ThemedCheckboxWidget(int x, int y, int width, int height,
                                BooleanSupplier getter, Consumer<Boolean> setter) {
        super(x, y, width, height, class_2561.method_43473());
        this.getter = getter;
        this.setter = setter;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int size = Math.min(SIZE, Math.min(field_22758, field_22759));
        int x = method_46426() + (field_22758 - size) / 2;
        int y = method_46427() + (field_22759 - size) / 2;
        class_2960 texture = getter.getAsBoolean() ? CHECKED : UNCHECKED;

        graphics.method_25290(class_10799.field_56883, texture, x, y, 0, 0, size, size, SIZE, SIZE);

        if (method_49606()) {
            graphics.method_73198(x - 1, y - 1, size + 2, size + 2, Theme.current().accentBright);
        }
    }

    @Override
    public void method_25348(class_11909 event, boolean doubleClick) {
        setter.accept(!getter.getAsBoolean());
    }

    @Override
    public void method_47399(class_6382 output) {
        output.method_37034(class_6381.field_33788, class_2561.method_43470(getter.getAsBoolean() ? "Enabled" : "Disabled"));
    }
}
