package dev.bobodado.acquiredutils.client.gui.widget;

import dev.bobodado.acquiredutils.client.gui.theme.Theme;
import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntSupplier;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3675;
import net.minecraft.class_6381;
import net.minecraft.class_6382;

public class LockedKeybindWidget extends class_339 implements KeyListenerSlot.Listener {

    private static final int CHECKBOX_SIZE = 12;
    private static final int KEY_BOX_WIDTH = 70;
    private static final int KEY_BOX_RIGHT_GAP = 20;
    private static final int CONTENT_LEFT_INSET = 7;

    private static final class_2960 CHECKBOX_CHECKED =
        class_2960.method_60655(
            "acquiredutils",
            "textures/gui/checkbox_purple_checked.png"
        );

    private static final class_2960 CHECKBOX_UNCHECKED =
        class_2960.method_60655(
            "acquiredutils",
            "textures/gui/checkbox_purple_unchecked.png"
        );
    
    private final KeyListenerSlot slot;
    private final BooleanSupplier enabledGetter;
    private final Consumer<Boolean> enabledSetter;
    private final IntSupplier keyGetter;
    private final Consumer<Integer> keySetter;

    public LockedKeybindWidget(
        int x,
        int y,
        int width,
        int height,
        class_2561 label,
        KeyListenerSlot slot,
        BooleanSupplier enabledGetter,
        Consumer<Boolean> enabledSetter,
        IntSupplier keyGetter,
        Consumer<Integer> keySetter
    ) {
        super(x, y, width, height, label);
        this.slot = slot;
        this.enabledGetter = enabledGetter;
        this.enabledSetter = enabledSetter;
        this.keyGetter = keyGetter;
        this.keySetter = keySetter;
    }

    @Override
    public void applyKeyCode(int keyCode) {
        keySetter.accept(keyCode);

        if (slot.isListening(this)) {
            slot.clear();
        }
    }

    @Override
    protected void method_48579(
        class_332 graphics,
        int mouseX,
        int mouseY,
        float partialTick
    ) {
        Theme theme = Theme.current();
        var font = class_310.method_1551().field_1772;

        boolean enabled = enabledGetter.getAsBoolean();
        boolean listening = slot.isListening(this);

        int cbSize = CHECKBOX_SIZE;
        int cbY = method_46427() + (field_22759 - cbSize) / 2;

        class_2960 checkboxTexture = enabled
            ? CHECKBOX_CHECKED
            : CHECKBOX_UNCHECKED;

        int cbX = method_46426() + CONTENT_LEFT_INSET;

        graphics.method_25290(
            class_10799.field_56883,
            checkboxTexture,
            cbX,
            cbY,
            0.0f,
            0.0f,
            CHECKBOX_SIZE,
            CHECKBOX_SIZE,
            CHECKBOX_SIZE,
            CHECKBOX_SIZE
        );

        if (listening) {
            graphics.method_73198(
                cbX - 1,
                cbY - 1,
                cbSize + 2,
                cbSize + 2,
                theme.accentBright
            );
        }

        int keyBoxW = KEY_BOX_WIDTH;
        int keyBoxX = method_46426() + field_22758 - keyBoxW - KEY_BOX_RIGHT_GAP;
        int keyCode = keyGetter.getAsInt();

        String keyText = listening
            ? "..."
            : (keyCode < 0
                ? "[NONE]"
                : class_3675.class_307.field_1668
                    .method_1447(keyCode)
                    .method_27445()
                    .getString());

        int keyColor = listening
            ? theme.accentBright
            : (keyCode < 0 ? theme.credit : theme.text);

        graphics.method_25294(
            keyBoxX,
            method_46427(),
            keyBoxX + keyBoxW,
            method_46427() + field_22759,
            theme.footerBottom
        );

        graphics.method_73198(
            keyBoxX,
            method_46427(),
            keyBoxW,
            field_22759,
            listening ? theme.accentBright : theme.frameMid
        );

        int textWidth = font.method_1727(keyText);

        graphics.method_51433(
            font,
            keyText,
            keyBoxX + (keyBoxW - textWidth) / 2,
            method_46427() + (field_22759 - 8) / 2,
            keyColor,
            false
        );
    }

    @Override
    public void method_25348(class_11909 event, boolean doubleClick) {
        double mouseX = event.comp_4798();
        double mouseY = event.comp_4799();

        int cbSize = CHECKBOX_SIZE;
        int cbY = method_46427() + (field_22759 - cbSize) / 2;

        int cbX = method_46426() + CONTENT_LEFT_INSET;

        boolean onCheckbox =
            mouseX >= cbX
            && mouseX < cbX + cbSize
            && mouseY >= cbY
            && mouseY < cbY + cbSize;

        if (onCheckbox) {
            enabledSetter.accept(!enabledGetter.getAsBoolean());
            return;
        }

        int keyBoxW = KEY_BOX_WIDTH;
        int keyBoxX = method_46426() + field_22758 - keyBoxW - KEY_BOX_RIGHT_GAP;

        boolean onKeyBox =
            mouseX >= keyBoxX
            && mouseX < keyBoxX + keyBoxW
            && mouseY >= method_46427()
            && mouseY < method_46427() + field_22759;

        if (onKeyBox) {
            slot.current = this;
        }
    }

    @Override
    public void method_47399(class_6382 output) {
        output.method_37034(class_6381.field_33788, method_25369());
    }
}
