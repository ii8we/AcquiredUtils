package dev.bobodado.acquiredutils.client.gui;

import dev.bobodado.acquiredutils.AcquiredUtils;
import dev.bobodado.acquiredutils.client.gui.section.GuiRow;
import dev.bobodado.acquiredutils.client.gui.section.ModSection;
import dev.bobodado.acquiredutils.client.gui.theme.Theme;
import dev.bobodado.acquiredutils.client.gui.widget.DropdownWidget;
import dev.bobodado.acquiredutils.client.gui.widget.ThemedButtonWidget;
import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10799;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_437;
import java.util.Locale;

public class AcquiredUtilsConfigScreen extends class_437 {

    private static final class_2960 ICON_GEAR =
        class_2960.method_60655("acquiredutils", "textures/gui/icon_gear.png");
    private static final class_2960 ICON_KEYBOARD =
        class_2960.method_60655("acquiredutils", "textures/gui/icon_keyboard.png");
    private static final class_2960 ICON_MOD =
        class_2960.method_60655("acquiredutils", "textures/gui/icon_header.png");
    private static final class_2960 ICON_MOD_SMALL =
        class_2960.method_60655("acquiredutils", "textures/gui/icon_mod.png");
    private static final class_2960 BACKGROUND_TEXTURE =
        class_2960.method_60655("acquiredutils", "textures/gui/menu_backdrop.png");

    public static final int BASE_PANEL_WIDTH = 560;
    public static final int BASE_PANEL_HEIGHT = 310;
    public static final int BASE_HEADER_HEIGHT = 56;
    public static final int BASE_FOOTER_HEIGHT = 28;
    public static final int BASE_SIDEBAR_WIDTH = 126;
    public static final int BASE_PADDING = 10;
    public static final int BASE_TAB_HEIGHT = 22;

    private final class_437 parent;

    private float menuScale;
    private int panelWidth, panelHeight, headerHeight, footerHeight;
    private int sidebarWidth, padding, tabHeight;
    private int panelX, panelY;

    private final Map<String, ModSection> sections = new LinkedHashMap<>();
    private String activeSectionId;
    private final List<class_339> sectionWidgets = new ArrayList<>();

    private final List<TabPos> tabPositions = new ArrayList<>();
    private record TabPos(int x, int y, int w, int h, String id) {}

    private final List<StoredText> storedTexts = new ArrayList<>();
    private record StoredText(
        String translationKey,
        int x,
        int y,
        boolean isLabel,
        int maxWidth
    ) {}

    private final List<RowCard> rowCards = new ArrayList<>();
    private record RowCard(int x, int y, int w, int h) {}

    private boolean needsRebuild = false;
    private class_342 searchBox;
    private String searchQuery = "";
    private static final int SEARCH_WIDTH_BASE = 150;
    private static final int SEARCH_HEIGHT_BASE = 18;

    private int contentScroll = 0;
    private int maxContentScroll = 0;
    private int sidebarScroll = 0;
    private int maxSidebarScroll = 0;

    private static final int ROW_HEIGHT_BASE = 62;
    private static final int ROW_GAP_BASE = 8;
    private static final int CONTENT_TOP_BASE = 36;

    public AcquiredUtilsConfigScreen(class_437 parent) {
        super(class_2561.method_43471("acquiredutils.gui.title"));
        this.parent = parent;
    }

    public void registerSection(ModSection section) {
        sections.put(section.getId(), section);

        if (activeSectionId == null) {
            activeSectionId = section.getId();
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    public net.minecraft.class_310 getMinecraft() {
        return this.field_22787;
    }

    public float getMenuScale() {
        return menuScale;
    }

    public int s(int base) {
        return (int) (base * menuScale);
    }

    public void addSectionWidget(class_339 widget) {
        sectionWidgets.add(widget);
        method_37063(widget);
    }

    public void scheduleRebuild() {
        needsRebuild = true;
    }

    @Override
    public void method_25393() {
        if (needsRebuild) {
            needsRebuild = false;
            boolean searchFocused = searchBox != null && searchBox.method_25370();
            method_25426();
            if (searchFocused && searchBox != null) {
                searchBox.method_25365(true);
                searchBox.method_1875(searchBox.method_1882().length());
            }
        }
    }

    private void computeLayout() {
        this.menuScale = AcquiredUtilsConfig.get().menuScale;

        float maxScaleX = (float) this.field_22789 / BASE_PANEL_WIDTH;
        float maxScaleY = (float) this.field_22790 / BASE_PANEL_HEIGHT;

        this.menuScale = Math.max(
            0.5f,
            Math.min(
                this.menuScale,
                Math.min(maxScaleX, maxScaleY)
            )
        );

        this.panelWidth = s(BASE_PANEL_WIDTH);
        this.panelHeight = s(BASE_PANEL_HEIGHT);
        this.headerHeight = s(BASE_HEADER_HEIGHT);
        this.footerHeight = s(BASE_FOOTER_HEIGHT);
        this.sidebarWidth = s(BASE_SIDEBAR_WIDTH);
        this.padding = s(BASE_PADDING);
        this.tabHeight = s(BASE_TAB_HEIGHT);
        this.panelX = (this.field_22789 - panelWidth) / 2;
        this.panelY = (this.field_22790 - panelHeight) / 2;
    }

    @Override
    protected void method_25426() {
        computeLayout();
        method_37067();
        sectionWidgets.clear();
        tabPositions.clear();
        storedTexts.clear();
        rowCards.clear();

        buildHeader();
        buildSearchBox();
        buildSidebarTabs();
        buildContent();
        buildFooterButton();
    }

    private void buildHeader() {
        // Intentionally empty: the header is visual only. The close button
        // lives in the footer to match the layout specification.
    }

    private void buildSearchBox() {
        int contentX = panelX + sidebarWidth + padding;
        int contentY = panelY + headerHeight + padding;
        int contentW = panelWidth - sidebarWidth - padding * 2;

        int width = s(SEARCH_WIDTH_BASE);
        int height = s(SEARCH_HEIGHT_BASE);
        int x = contentX + contentW - width - s(4);
        int y = contentY + s(6);

        searchBox = new class_342(
            this.field_22793,
            x,
            y,
            width,
            height,
            class_2561.method_43471("acquiredutils.gui.search")
        );
        searchBox.method_1880(80);
        searchBox.method_1858(true);
        searchBox.method_1868(0xFFF2EAF7);
        searchBox.method_1887(searchQuery.isEmpty() ? "Search settings..." : null);
        searchBox.method_47404(class_2561.method_43471("acquiredutils.gui.search"));
        searchBox.method_1852(searchQuery);
        searchBox.method_1863(value -> {
            String normalized = value.trim().toLowerCase(Locale.ROOT);
            if (!normalized.equals(searchQuery)) {
                searchQuery = normalized;
                searchBox.method_1887(normalized.isEmpty() ? "Search settings..." : null);
                contentScroll = 0;
                sidebarScroll = 0;
                needsRebuild = true;
            }
        });

        method_37063(searchBox);
    }

    private void buildFooterButton() {
        int closeWidth = s(24);
        int closeHeight = s(18);
        method_37063(new ThemedButtonWidget(
            panelX + panelWidth - closeWidth - padding,
            panelY + panelHeight - footerHeight + (footerHeight - closeHeight) / 2,
            closeWidth,
            closeHeight,
            class_2561.method_43470("×"),
            this::method_25419
        ));
    }

    private void buildSidebarTabs() {
        int tabX = panelX + padding;
        int tabWidth = sidebarWidth - padding * 2;
        int baseTabY = panelY + headerHeight + padding;
        int gap = s(4);

        List<ModSection> matchingSections = getMatchingSections();

        if (searchQuery.isEmpty() == false
            && !matchingSections.isEmpty()
            && !matchingSections.stream().anyMatch(section -> section.getId().equals(activeSectionId))) {
            activeSectionId = matchingSections.get(0).getId();
        }

        int totalHeight = matchingSections.size() * tabHeight
            + Math.max(0, matchingSections.size() - 1) * gap;
        int viewportHeight = panelHeight - headerHeight - footerHeight - padding * 2;
        maxSidebarScroll = Math.max(0, totalHeight - viewportHeight);
        sidebarScroll = Math.max(0, Math.min(sidebarScroll, maxSidebarScroll));

        int i = 0;
        for (ModSection section : matchingSections) {
            final String id = section.getId();
            int y = baseTabY + i * (tabHeight + gap) - sidebarScroll;

            tabPositions.add(new TabPos(tabX, y, tabWidth, tabHeight, id));

            ThemedButtonWidget tab = new ThemedButtonWidget(
                tabX, y, tabWidth, tabHeight,
                section.getDisplayName(),
                () -> switchTab(id),
                true
            );

            tab.field_22764 = y + tabHeight > panelY + headerHeight
                && y < panelY + panelHeight - footerHeight;

            method_37063(tab);
            i++;
        }
    }

    private List<ModSection> getMatchingSections() {
        if (searchQuery.isEmpty()) {
            return new ArrayList<>(sections.values());
        }

        List<ModSection> result = new ArrayList<>();
        for (ModSection section : sections.values()) {
            if (matchesSection(section)) {
                result.add(section);
            }
        }
        return result;
    }

    private boolean matchesSection(ModSection section) {
        String name = section.getDisplayName().getString().toLowerCase(Locale.ROOT);
        if (name.contains(searchQuery)) {
            return true;
        }

        for (GuiRow row : section.getRows()) {
            String label = row.labelKey() == null
                ? ""
                : class_2561.method_43471(row.labelKey()).getString().toLowerCase(Locale.ROOT);
            String desc = row.descKey() == null
                ? ""
                : class_2561.method_43471(row.descKey()).getString().toLowerCase(Locale.ROOT);

            if (label.contains(searchQuery) || desc.contains(searchQuery)) {
                return true;
            }
        }
        return false;
    }

    private List<GuiRow> getFilteredRows(ModSection section) {
        List<GuiRow> rows = section.getRows();
        if (searchQuery.isEmpty()) {
            return rows;
        }

        List<GuiRow> result = new ArrayList<>();
        for (GuiRow row : rows) {
            String label = row.labelKey() == null
                ? ""
                : class_2561.method_43471(row.labelKey()).getString().toLowerCase(Locale.ROOT);
            String desc = row.descKey() == null
                ? ""
                : class_2561.method_43471(row.descKey()).getString().toLowerCase(Locale.ROOT);

            if (label.contains(searchQuery) || desc.contains(searchQuery)) {
                result.add(row);
            }
        }
        return result;
    }

    private void buildContent() {
        ModSection active = sections.get(activeSectionId);
        if (active == null) return;

        int contentX = panelX + sidebarWidth + padding;
        int contentY = panelY + headerHeight + padding;
        int contentW = panelWidth - sidebarWidth - padding * 2;
        int contentH = panelHeight - headerHeight - footerHeight - padding * 2;

        List<GuiRow> rows = getFilteredRows(active);
        int rowHeight = s(ROW_HEIGHT_BASE);
        int rowGap = s(ROW_GAP_BASE);
        int contentTop = contentY + s(CONTENT_TOP_BASE);
        int viewportHeight = contentH - s(CONTENT_TOP_BASE);

        int totalHeight = rows.isEmpty()
            ? 0
            : rows.size() * rowHeight + (rows.size() - 1) * rowGap;

        maxContentScroll = Math.max(0, totalHeight - viewportHeight);
        contentScroll = Math.max(0, Math.min(contentScroll, maxContentScroll));

        // Reserve a clean scrollbar gutter so the bar never sits on top of
        // setting cards or controls.
        int scrollbarGutter = s(12);
        int bodyW = Math.max(s(160), contentW - scrollbarGutter);

        int rowY = contentTop - contentScroll;

        if (rows.isEmpty() && !searchQuery.isEmpty()) {
            rowCards.add(new RowCard(
                contentX,
                contentTop,
                bodyW,
                rowHeight
            ));
        }

        for (GuiRow row : rows) {
            int controlW = row.controlWidth() < 0
                ? bodyW
                : Math.min(s(row.controlWidth()), bodyW);

            int controlH = s(row.controlHeight());
            int controlShift = row.controlWidth() < 0 ? 0 : s(12);
            int controlX = row.controlWidth() < 0
                ? contentX
                : contentX + bodyW - controlW - controlShift;

            int controlY = rowY + s(8);

            class_339 widget = row.factory().create(
                controlX,
                controlY,
                controlW,
                controlH
            );

            int viewportTop = contentY + s(22);
            int viewportBottom = contentY + contentH;
            widget.field_22764 = rowY + rowHeight > viewportTop
                && rowY < viewportBottom;

            rowCards.add(new RowCard(
                contentX,
                rowY,
                bodyW,
                rowHeight
            ));

            addSectionWidget(widget);

            int textX = contentX + s(16);
            int textWidth = row.controlWidth() < 0
                ? bodyW - s(24)
                : Math.max(s(90), bodyW - controlW - s(40));

            if (row.labelKey() != null) {
                storedTexts.add(new StoredText(
                    row.labelKey(),
                    textX,
                    rowY + s(6),
                    true,
                    textWidth
                ));
            }

            if (row.descKey() != null) {
                storedTexts.add(new StoredText(
                    row.descKey(),
                    textX,
                    rowY + s(28),
                    false,
                    textWidth
                ));
            }

            rowY += rowHeight + rowGap;
        }
    }

    private void switchTab(String id) {
        ModSection old = sections.get(activeSectionId);

        if (old != null) {
            old.onClose();
        }

        activeSectionId = id;
        method_25426();
    }

    @Override
    public void method_25394(
        class_332 graphics,
        int mouseX,
        int mouseY,
        float partialTick
    ) {
        Theme theme = Theme.current();

        graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0x4C05030A);

        drawPanelChrome(graphics, theme);

        graphics.method_44379(panelX, panelY, panelX + panelWidth, panelY + panelHeight);
        graphics.method_25290(
            class_10799.field_56883,
            BACKGROUND_TEXTURE,
            panelX, panelY,
            0.0f, 0.0f,
            panelWidth, panelHeight,
            1600, 900
        );
        graphics.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0x7A07030F);
        graphics.method_44380();

        int logoSize = Math.min(s(24), headerHeight - s(6));
        int logoX = panelX + padding + s(3);
        int logoY = panelY + (headerHeight - logoSize) / 2;

        graphics.method_25290(
            class_10799.field_56883,
            ICON_MOD,
            logoX,
            logoY,
            0.0f, 0.0f,
            logoSize, logoSize,
            32, 32
        );

        int titleX = logoX + logoSize + s(5);
        int titleY = panelY + (headerHeight - this.field_22793.field_2000) / 2;

        class_2561 titlePrefix = class_2561.method_43470("AcquiredUtils")
            .method_27661()
            .method_27696(class_2583.field_24360.method_10982(true));
        class_2561 titleBy = class_2561.method_43470(" by ");
        class_2561 titleAuthor = class_2561.method_43470("ii8we")
            .method_27661()
            .method_27696(class_2583.field_24360.method_10982(true));

        graphics.method_51439(this.field_22793, titlePrefix, titleX, titleY, theme.accentBright, false);
        int afterPrefix = titleX + this.field_22793.method_27525(titlePrefix);
        graphics.method_51439(this.field_22793, titleBy, afterPrefix, titleY, theme.text, false);
        int afterBy = afterPrefix + this.field_22793.method_27525(titleBy);
        graphics.method_51439(this.field_22793, titleAuthor, afterBy, titleY, theme.text, false);

        String version = "v1.0.0";
        graphics.method_51439(
            this.field_22793,
            class_2561.method_43470(version),
            panelX + panelWidth - padding - this.field_22793.method_1727(version),
            titleY,
            theme.credit,
            false
        );

        int underlineY = panelY + headerHeight - 1;

        graphics.method_25294(
            panelX,
            underlineY,
            panelX + panelWidth,
            underlineY + 1,
            theme.divider
        );
        graphics.method_25294(
            panelX + s(2),
            underlineY - s(1),
            panelX + s(34),
            underlineY + s(1),
            theme.accentBright
        );

        graphics.method_25294(
            panelX + sidebarWidth,
            panelY + headerHeight,
            panelX + sidebarWidth + 1,
            panelY + panelHeight - footerHeight,
            theme.divider
        );

        graphics.method_51439(
            this.field_22793,
            class_2561.method_43470("Settings are saved automatically"),
            panelX + padding,
            panelY + panelHeight - footerHeight + s(9),
            theme.credit,
            false
        );

        int contentX = panelX + sidebarWidth + padding;
        int contentY = panelY + headerHeight + padding;
        int contentW = panelWidth - sidebarWidth - padding * 2;
        int contentH = panelHeight - headerHeight - footerHeight - padding * 2;

        ModSection active = sections.get(activeSectionId);

        graphics.method_25294(
            contentX,
            contentY,
            contentX + contentW,
            contentY + contentH,
            0xA8120C1A
        );

        graphics.method_25294(
            contentX + s(4),
            contentY + s(7),
            contentX + contentW - s(4),
            contentY + s(8),
            theme.divider
        );

        graphics.method_44379(
            contentX,
            contentY,
            contentX + contentW,
            contentY + contentH
        );

        for (RowCard card : rowCards) {
            drawRowCard(graphics, card, theme);
        }

        if (active != null) {
            active.render(
                graphics,
                mouseX,
                mouseY,
                partialTick,
                contentX,
                contentY,
                Math.max(s(160), contentW - s(12)),
                contentH
            );
        }

        graphics.method_44380();

        drawScrollbars(graphics, theme, contentX, contentY, contentW, contentH);

        // Content widgets are rendered separately under the viewport scissor.
        // This prevents buttons/sliders/dropdowns from leaking outside the
        // scrollable area when the user scrolls up or down.
        List<Boolean> contentVisibility = new ArrayList<>(sectionWidgets.size());
        for (class_339 widget : sectionWidgets) {
            contentVisibility.add(widget.field_22764);
            widget.field_22764 = false;
        }
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        for (int i = 0; i < sectionWidgets.size(); i++) {
            sectionWidgets.get(i).field_22764 = contentVisibility.get(i);
        }

        graphics.method_44379(
            contentX,
            contentY,
            contentX + contentW,
            contentY + contentH
        );

        for (class_339 widget : sectionWidgets) {
            if (widget.field_22764) {
                widget.method_25394(graphics, mouseX, mouseY, partialTick);
            }
        }

        for (StoredText st : storedTexts) {
            if (st.isLabel()) {
                drawLabel(
                    graphics,
                    class_2561.method_43471(st.translationKey()),
                    st.x(),
                    st.y()
                );
            } else {
                drawDescription(
                    graphics,
                    st.translationKey(),
                    st.x(),
                    st.y(),
                    st.maxWidth()
                );
            }
        }

        graphics.method_44380();

        if (active != null && getFilteredRows(active).isEmpty() && !searchQuery.isEmpty()) {
            graphics.method_51439(
                this.field_22793,
                class_2561.method_43471("acquiredutils.gui.search.no_results"),
                contentX + s(16),
                contentY + s(46),
                theme.credit,
                false
            );
        }

        for (TabPos tab : tabPositions) {
            class_2960 icon = switch (tab.id()) {
                case "general" -> ICON_GEAR;
                case "keybinds" -> ICON_KEYBOARD;
                default -> ICON_MOD_SMALL;
            };

            int iconSize = Math.min(s(12), tab.h() - s(6));
            int iconX = tab.x() + s(6);
            int iconY = tab.y() + (tab.h() - iconSize) / 2;
            graphics.method_25290(
                class_10799.field_56883,
                icon,
                iconX, iconY,
                0.0f, 0.0f,
                iconSize, iconSize,
                16,
                16
            );

            if (tab.id().equals(activeSectionId)) {
                int edgeW = Math.max(1, s(3));
                graphics.method_25294(
                    tab.x(), tab.y(), tab.x() + edgeW, tab.y() + tab.h(),
                    theme.accentBright
                );
            }
        }

        for (class_339 w : sectionWidgets) {
            if (w instanceof DropdownWidget d && d.isOpen()) {
                d.renderOverlay(
                    graphics,
                    mouseX,
                    mouseY,
                    partialTick
                );
            }
        }
    }

    private void drawScrollbars(
        class_332 graphics,
        Theme theme,
        int contentX,
        int contentY,
        int contentW,
        int contentH
    ) {
        int barWidth = Math.max(2, s(3));

        if (maxContentScroll > 0) {
            int gutter = s(12);
            int trackX = contentX + contentW - gutter / 2 - barWidth / 2;
            int trackY = contentY + s(28);
            int trackH = contentH - s(34);

            graphics.method_25294(
                trackX,
                trackY,
                trackX + barWidth,
                trackY + trackH,
                theme.sliderTrack
            );

            int thumbH = Math.max(
                s(22),
                (int) ((trackH * (double) trackH) / (trackH + maxContentScroll))
            );
            int travel = Math.max(0, trackH - thumbH);
            int thumbY = trackY + (int) (travel *
                (contentScroll / (double) maxContentScroll));

            graphics.method_25294(
                trackX - 1,
                thumbY,
                trackX + barWidth + 1,
                thumbY + thumbH,
                theme.accent
            );
        }

        if (maxSidebarScroll > 0) {
            int trackX = panelX + sidebarWidth - s(4);
            int trackY = panelY + headerHeight + padding;
            int trackH = panelHeight - headerHeight - footerHeight - padding * 2;

            graphics.method_25294(
                trackX,
                trackY,
                trackX + barWidth,
                trackY + trackH,
                theme.sliderTrack
            );

            int thumbH = Math.max(
                s(18),
                (int) ((trackH * (double) trackH) / (trackH + maxSidebarScroll))
            );
            int travel = Math.max(0, trackH - thumbH);
            int thumbY = trackY + (int) (travel *
                (sidebarScroll / (double) maxSidebarScroll));

            graphics.method_25294(
                trackX - 1,
                thumbY,
                trackX + barWidth + 1,
                thumbY + thumbH,
                theme.accent
            );
        }
    }

    private void drawRowCard(class_332 graphics, RowCard card, Theme theme) {
        int inset = Math.max(1, s(1));

        graphics.method_25294(
            card.x(), card.y(),
            card.x() + card.w(), card.y() + card.h(),
            0xA0181220
        );

        graphics.method_73198(
            card.x(), card.y(), card.w(), card.h(), theme.frameMid
        );

        graphics.method_25294(
            card.x() + inset, card.y() + inset,
            card.x() + s(3), card.y() + card.h() - inset,
            theme.accent
        );
    }

    private void drawPanelChrome(class_332 graphics, Theme theme) {
        int ft = Math.max(1, s(4));
        int shadowOffset = Math.max(1, s(3));

        graphics.method_25294(
            panelX - ft + shadowOffset,
            panelY - ft + shadowOffset,
            panelX + panelWidth + ft + shadowOffset,
            panelY + panelHeight + ft + shadowOffset,
            theme.shadow
        );

        graphics.method_25296(
            panelX,
            panelY,
            panelX + panelWidth,
            panelY + panelHeight,
            theme.panelTop,
            theme.panelBottom
        );

        graphics.method_73198(
            panelX - ft,
            panelY - ft,
            panelWidth + ft * 2,
            panelHeight + ft * 2,
            theme.frameOuter
        );

        graphics.method_73198(
            panelX - ft + 1,
            panelY - ft + 1,
            panelWidth + ft * 2 - 2,
            panelHeight + ft * 2 - 2,
            theme.frameMid
        );

        graphics.method_73198(
            panelX - 1,
            panelY - 1,
            panelWidth + 2,
            panelHeight + 2,
            theme.frameAccent
        );

        drawCornerAccents(
            graphics,
            panelX - ft,
            panelY - ft,
            panelWidth + ft * 2,
            panelHeight + ft * 2,
            theme
        );

        graphics.method_25296(
            panelX,
            panelY,
            panelX + panelWidth,
            panelY + headerHeight,
            theme.headerTop,
            theme.headerBottom
        );

        graphics.method_25296(
            panelX,
            panelY + headerHeight,
            panelX + sidebarWidth,
            panelY + panelHeight - footerHeight,
            theme.sidebarTop,
            theme.sidebarBottom
        );

        graphics.method_25296(
            panelX,
            panelY + panelHeight - footerHeight,
            panelX + panelWidth,
            panelY + panelHeight,
            theme.footerTop,
            theme.footerBottom
        );
    }

    private void drawCornerAccents(
        class_332 graphics,
        int x,
        int y,
        int w,
        int h,
        Theme theme
    ) {
        int len = Math.max(2, s(9));
        int thick = Math.max(1, s(2));

        graphics.method_25294(x, y, x + len, y + thick, theme.accentBright);
        graphics.method_25294(x, y, x + thick, y + len, theme.accentBright);

        graphics.method_25294(
            x + w - len,
            y,
            x + w,
            y + thick,
            theme.accentBright
        );

        graphics.method_25294(
            x + w - thick,
            y,
            x + w,
            y + len,
            theme.accentBright
        );

        graphics.method_25294(
            x,
            y + h - thick,
            x + len,
            y + h,
            theme.accentBright
        );

        graphics.method_25294(
            x,
            y + h - len,
            x + thick,
            y + h,
            theme.accentBright
        );

        graphics.method_25294(
            x + w - len,
            y + h - thick,
            x + w,
            y + h,
            theme.accentBright
        );

        graphics.method_25294(
            x + w - thick,
            y + h - len,
            x + w,
            y + h,
            theme.accentBright
        );
    }

    public void drawDescription(
        class_332 graphics,
        String translationKey,
        int x,
        int y,
        int maxWidth
    ) {
        class_2561 desc = class_2561.method_43471(translationKey)
            .method_27661();

        int safeWidth = Math.max(80, maxWidth);
        String value = desc.getString();
        class_2561 display = desc;

        while (value.length() > 1 && this.field_22793.method_27525(display) > safeWidth) {
            value = value.substring(0, value.length() - 1).stripTrailing();
            display = class_2561.method_43470(value + "...")
                .method_27661();
        }

        graphics.method_51439(
            this.field_22793,
            display,
            x,
            y,
            0xFFD3C9DE,
            false
        );
    }

    private void drawLabel(
        class_332 graphics,
        class_2561 label,
        int x,
        int y
    ) {
        class_2561 styled = label.method_27661().method_27696(
            class_2583.field_24360.method_10982(true)
        );

        graphics.method_51439(
            this.field_22793,
            styled,
            x,
            y,
            Theme.current().text,
            false
        );
    }

    @Override
    public boolean method_25402(
        class_11909 event,
        boolean doubleClick
    ) {
        double mouseX = event.comp_4798();
        double mouseY = event.comp_4799();

        for (class_339 w : sectionWidgets) {
            if (w instanceof DropdownWidget d && d.isOpen()) {
                if (!d.method_25405(mouseX, mouseY)
                    && !d.isOverExpandedArea(mouseX, mouseY)) {

                    d.setOpen(false);
                }
            }
        }

        ModSection active = sections.get(activeSectionId);

        if (active != null
            && active.mouseClicked(mouseX, mouseY, event.method_74245())) {

            return true;
        }

        return super.method_25402(event, doubleClick);
    }

    @Override
    public boolean method_25401(
        double mouseX,
        double mouseY,
        double scrollX,
        double scrollY
    ) {
        int contentX = panelX + sidebarWidth + padding;
        int contentY = panelY + headerHeight + padding;
        int contentW = panelWidth - sidebarWidth - padding * 2;
        int contentH = panelHeight - headerHeight - footerHeight - padding * 2;

        boolean insideContent = mouseX >= contentX
            && mouseX < contentX + contentW
            && mouseY >= contentY
            && mouseY < contentY + contentH;

        boolean insideSidebar = mouseX >= panelX + padding
            && mouseX < panelX + sidebarWidth - padding
            && mouseY >= panelY + headerHeight + padding
            && mouseY < panelY + panelHeight - footerHeight - padding;

        int steps = (int) Math.signum(scrollY);

        if (insideContent && maxContentScroll > 0 && steps != 0) {
            int delta = Math.max(s(20), Math.abs(steps) * s(30));
            contentScroll = Math.max(0, Math.min(maxContentScroll, contentScroll - (scrollY > 0 ? delta : -delta)));
            method_25426();
            return true;
        }

        if (insideSidebar && maxSidebarScroll > 0 && steps != 0) {
            int delta = Math.max(s(20), Math.abs(steps) * s(30));
            sidebarScroll = Math.max(0, Math.min(maxSidebarScroll, sidebarScroll - (scrollY > 0 ? delta : -delta)));
            method_25426();
            return true;
        }

        ModSection active = sections.get(activeSectionId);
        if (active != null && active.mouseScrolled(mouseX, mouseY, scrollX, scrollY)) {
            return true;
        }

        return super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        ModSection active = sections.get(activeSectionId);

        if (active != null
            && active.keyPressed(
                event.comp_4795(),
                event.comp_4796(),
                event.comp_4797()
            )) {

            return true;
        }

        return super.method_25404(event);
    }

    @Override
    public void method_25419() {
        for (ModSection section : sections.values()) {
            section.onClose();
        }

        AcquiredUtilsConfig.saveIfDirty();

        AcquiredUtils.LOGGER.info(
            "[AcquiredUtils] Settings saved on menu close"
        );

        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }
}