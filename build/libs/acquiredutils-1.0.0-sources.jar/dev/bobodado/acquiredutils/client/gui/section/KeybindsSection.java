package dev.bobodado.acquiredutils.client.gui.section;

import dev.bobodado.acquiredutils.client.gui.AcquiredUtilsConfigScreen;
import dev.bobodado.acquiredutils.client.gui.widget.KeyListenerSlot;
import dev.bobodado.acquiredutils.client.gui.widget.LockedKeybindWidget;
import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_3675;

public class KeybindsSection extends ModSection {

    private final KeyListenerSlot keybindSlot = new KeyListenerSlot();

    public KeybindsSection(AcquiredUtilsConfigScreen screen) {
        super(screen);
    }

    @Override
    public String getId() {
        return "keybinds";
    }

    @Override
    public class_2561 getDisplayName() {
        return class_2561.method_43471("acquiredutils.gui.tab.keybinds");
    }

    @Override
    public List<GuiRow> getRows() {
        AcquiredUtilsConfig cfg = AcquiredUtilsConfig.get();

        return List.of(
            new GuiRow(
                "acquiredutils.gui.keybind.slot_lock",
                "acquiredutils.gui.desc.slot_lock",
                22, -1, 22, 40,
                (x, y, w, h) -> new LockedKeybindWidget(
                    x, y, w, h,
                    class_2561.method_43471("acquiredutils.gui.keybind.slot_lock"),
                    keybindSlot,
                    () -> cfg.slotLockEnabled,
                    enabled -> {
                        cfg.slotLockEnabled = enabled;
                        if (enabled && cfg.slotLockKey < 0) {
                            cfg.slotLockKey = class_3675.field_31915;
                        }
                        cfg.markDirty();
                        AcquiredUtilsConfig.saveIfDirty();
                    },
                    () -> cfg.slotLockKey,
                    keyCode -> {
                        cfg.slotLockKey = keyCode;
                        cfg.markDirty();
                    }
                )
            ),
            new GuiRow(
                "acquiredutils.gui.keybind.inventory_search",
                "acquiredutils.gui.desc.keybind_inventory_search",
                22, -1, 22, 40,
                (x, y, w, h) -> new LockedKeybindWidget(
                    x, y, w, h,
                    class_2561.method_43471("acquiredutils.gui.keybind.inventory_search"),
                    keybindSlot,
                    () -> true,
                    enabled -> {},
                    () -> cfg.inventorySearchKey,
                    keyCode -> {
                        cfg.inventorySearchKey = keyCode;
                        cfg.markDirty();
                    }
                )
            )
        );
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keybindSlot.current != null) {
            if (keyCode == 256) {
                keyCode = -1;
            }
            keybindSlot.current.applyKeyCode(keyCode);
            return true;
        }
        return false;
    }

    @Override
    public void onClose() {
        keybindSlot.clear();
    }
}
