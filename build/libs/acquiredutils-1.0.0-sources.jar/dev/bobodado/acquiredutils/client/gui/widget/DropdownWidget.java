package dev.bobodado.acquiredutils.client.gui.widget;

import dev.bobodado.acquiredutils.client.gui.theme.Theme;
import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6381;
import net.minecraft.class_6382;

public class DropdownWidget extends class_339 {

    private static final int ROW_HEIGHT = 12;

    private final List<class_2561> options;
    private final Consumer<Integer> onSelect;
    private int selectedIndex;
    private boolean open;

    public DropdownWidget(
        int x,
        int y,
        int width,
        int height,
        List<class_2561> options,
        int initialSelectedIndex,
        Consumer<Integer> onSelect
    ) {
        super(x, y, width, height, options.get(initialSelectedIndex));
        this.options = options;
        this.selectedIndex = initialSelectedIndex;
        this.onSelect = onSelect;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    @Override
    protected void method_48579(
        class_332 graphics,
        int mouseX,
        int mouseY,
        float partialTick
    ) {
        Theme theme = Theme.current();
        var font = class_310.method_1551().field_1772;

        int background = method_49606()
            ? theme.headerTop
            : theme.headerBottom;

        graphics.method_25294(
            method_46426(),
            method_46427(),
            method_46426() + field_22758,
            method_46427() + field_22759,
            background
        );

        graphics.method_73198(
            method_46426(),
            method_46427(),
            field_22758,
            field_22759,
            method_49606() ? theme.accentBright : theme.frameMid
        );

        graphics.method_51439(
            font,
            options.get(selectedIndex),
            method_46426() + 4,
            method_46427() + (field_22759 - 8) / 2,
            theme.text,
            false
        );

        graphics.method_51433(
            font,
            "▾",
            method_46426() + field_22758 - 10,
            method_46427() + (field_22759 - 8) / 2,
            theme.accentBright,
            false
        );
    }

    public void renderOverlay(
        class_332 graphics,
        int mouseX,
        int mouseY,
        float partialTick
    ) {
        if (!open) return;

        Theme theme = Theme.current();

        int listY = method_46427() + field_22759;
        int rowHeight = ROW_HEIGHT;
        int listHeight = options.size() * rowHeight;

        graphics.method_25294(
            method_46426(),
            listY,
            method_46426() + field_22758,
            listY + listHeight,
            theme.panelBottom
        );

        graphics.method_73198(
            method_46426(),
            listY,
            field_22758,
            listHeight,
            theme.accentBright
        );

        for (int i = 0; i < options.size(); i++) {
            int rowY = listY + i * rowHeight;

            if (i == selectedIndex) {
                graphics.method_25294(
                    method_46426() + 1,
                    rowY,
                    method_46426() + field_22758 - 1,
                    rowY + rowHeight,
                    theme.tabActiveBg
                );
            }

            graphics.method_51439(
                class_310.method_1551().field_1772,
                options.get(i),
                method_46426() + 4,
                rowY + 2,
                theme.text,
                false
            );
        }
    }

    @Override
    public void method_25348(class_11909 event, boolean doubleClick) {
        double mouseX = event.comp_4798();
        double mouseY = event.comp_4799();

        if (open) {
            int listY = method_46427() + field_22759;
            int rowHeight = ROW_HEIGHT;
            int listHeight = options.size() * rowHeight;

            if (mouseX >= method_46426()
                && mouseX < method_46426() + field_22758
                && mouseY >= listY
                && mouseY < listY + listHeight) {

                int index = ((int) mouseY - listY) / rowHeight;

                if (index >= 0 && index < options.size()) {
                    selectedIndex = index;
                    method_25355(options.get(index));
                    onSelect.accept(index);
                }

                open = false;
                return;
            }

            open = false;
            return;
        }

        if (method_25405(mouseX, mouseY)) {
            open = true;
        }
    }

    public boolean isOverExpandedArea(double mouseX, double mouseY) {
        if (!open) {
            return method_25405(mouseX, mouseY);
        }

        int listY = method_46427() + field_22759;
        int listHeight = options.size() * ROW_HEIGHT;

        return mouseX >= method_46426()
            && mouseX < method_46426() + field_22758
            && mouseY >= listY
            && mouseY < listY + listHeight;
    }

    @Override
    public void method_47399(class_6382 output) {
        output.method_37034(
            class_6381.field_33788,
            options.get(selectedIndex)
        );
    }
}
