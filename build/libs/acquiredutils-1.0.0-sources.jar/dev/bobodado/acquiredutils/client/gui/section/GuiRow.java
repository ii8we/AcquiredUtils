package dev.bobodado.acquiredutils.client.gui.section;

import net.minecraft.class_339;

public record GuiRow(
    String labelKey,
    String descKey,
    int descOffsetY,
    int controlWidth,
    int controlHeight,
    int rowSpacing,
    ControlFactory factory
) {

    @FunctionalInterface
    public interface ControlFactory {
        class_339 create(int x, int y, int width, int height);
    }
}