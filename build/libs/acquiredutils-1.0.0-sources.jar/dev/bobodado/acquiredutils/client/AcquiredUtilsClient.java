package dev.bobodado.acquiredutils.client;

import dev.bobodado.acquiredutils.AcquiredUtils;
import dev.bobodado.acquiredutils.client.gui.AcquiredUtilsConfigScreen;
import dev.bobodado.acquiredutils.client.gui.section.GeneralSection;
import dev.bobodado.acquiredutils.client.gui.section.OverlaysSection;
import dev.bobodado.acquiredutils.client.gui.section.ItemPickupSection;
import dev.bobodado.acquiredutils.client.gui.section.KeybindsSection;
import dev.bobodado.acquiredutils.client.pickup.ItemPickupNotifier;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_437;

public class AcquiredUtilsClient implements ClientModInitializer {

    private static final class_304.class_11900 CATEGORY =
        class_304.class_11900.method_74698(class_2960.method_60655(AcquiredUtils.MOD_ID, "acquiredutils"));

    private static class_304 openConfigKey;

    @Override
    public void onInitializeClient() {
        AcquiredUtils.LOGGER.info("[AcquiredUtils] Initializing client entrypoint");

        openConfigKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.acquiredutils.open_config",
            class_3675.class_307.field_1668,
            class_3675.field_31934,
            CATEGORY
        ));

        SlotLockHandler.init();
        InventorySearchHandler.init();
        ContainerOverlayHandler.init();
        ItemPickupNotifier.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openConfigKey.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(createConfigScreen(null));
                }
            }
        });
    }

    public static AcquiredUtilsConfigScreen createConfigScreen(class_437 parent) {
        AcquiredUtilsConfigScreen screen = new AcquiredUtilsConfigScreen(parent);
        screen.registerSection(new GeneralSection(screen));
        screen.registerSection(new ItemPickupSection(screen));
        screen.registerSection(new OverlaysSection(screen));
        screen.registerSection(new KeybindsSection(screen));
        return screen;
    }
}