package dev.bobodado.acquiredutils.client;

import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;

public final class ItemComparisonHandler {

    private static final Pattern NUMERIC_STAT =
        Pattern.compile("^\\s*([^:]{2,40}):\\s*([+-]?\\d+(?:\\.\\d+)?)");

    private ItemComparisonHandler() {
    }

    public static void render(
        class_332 graphics,
        class_465<?> screen,
        class_1657 player,
        int mouseX,
        int mouseY,
        int tooltipLineCount
    ) {
        if (!AcquiredUtilsConfig.get().itemComparisonEnabled || player == null) {
            return;
        }

        class_1735 hovered = screen.field_2787;
        if (hovered == null || !hovered.method_7681()) {
            return;
        }

        class_1799 candidate = hovered.method_7677();
        class_1304 equipmentSlot = player.method_32326(candidate);

        if (!player.method_63623(candidate, equipmentSlot)) {
            return;
        }

        class_1799 equipped = player.method_6118(equipmentSlot);
        if (equipped.method_7960() || class_1799.method_31577(candidate, equipped)) {
            return;
        }

        Map<String, Double> candidateStats = parseStats(candidate, player);
        Map<String, Double> equippedStats = parseStats(equipped, player);

        if (candidateStats.isEmpty() || equippedStats.isEmpty()) {
            return;
        }

        List<String> differences = new ArrayList<>();
        for (Map.Entry<String, Double> entry : candidateStats.entrySet()) {
            Double oldValue = equippedStats.get(entry.getKey());
            if (oldValue == null) {
                continue;
            }

            double delta = entry.getValue() - oldValue;
            if (Math.abs(delta) < 0.0001) {
                continue;
            }

            differences.add(formatDelta(entry.getKey(), delta));
            if (differences.size() >= 5) {
                break;
            }
        }

        if (differences.isEmpty()) {
            return;
        }

        class_310 mc = class_310.method_1551();
        int panelW = 150;
        int panelH = 18 + differences.size() * 10;

        int screenW = mc.method_22683().method_4486();
        int screenH = mc.method_22683().method_4502();

        // Keep the comparison HUD on the left of the cursor so it does not
        // cover the item tooltip or the hovered slot.
        int panelX = mouseX - panelW - 12;
        int panelY = mouseY + 12 + Math.min(tooltipLineCount * 9, 90);

        if (panelX < 4) {
            panelX = 4;
        }
        if (panelY + panelH > screenH) {
            panelY = screenH - panelH - 4;
        }

        graphics.method_25294(panelX, panelY, panelX + panelW, panelY + panelH, 0xE60B0712);
        graphics.method_73198(panelX, panelY, panelW, panelH, 0xFF7C5C9E);

        graphics.method_51439(
            mc.field_1772,
            class_2561.method_43470("Comparison"),
            panelX + 6,
            panelY + 5,
            0xFFE5B85C,
            true
        );

        int y = panelY + 16;
        for (String line : differences) {
            int color = line.startsWith("+") ? 0xFF6DFF9B : 0xFFFF7F91;
            graphics.method_51439(
                mc.field_1772,
                class_2561.method_43470(line),
                panelX + 6,
                y,
                color,
                false
            );
            y += 10;
        }
    }

    private static Map<String, Double> parseStats(class_1799 stack, class_1657 player) {
        List<class_2561> lines = stack.method_7950(
            class_1792.class_9635.method_59528(player.method_73183()),
            player,
            class_1836.class_1837.field_41070
        );

        Map<String, Double> result = new LinkedHashMap<>();

        for (int i = 1; i < lines.size(); i++) {
            Matcher matcher = NUMERIC_STAT.matcher(lines.get(i).getString());
            if (!matcher.find()) {
                continue;
            }

            try {
                String statName = matcher.group(1).trim();
                if (statName.toLowerCase(java.util.Locale.ROOT).contains("mana cost")) {
                    continue;
                }
                result.put(
                    statName,
                    Double.parseDouble(matcher.group(2))
                );
            } catch (NumberFormatException ignored) {
            }
        }

        return result;
    }

    private static String formatDelta(String name, double delta) {
        String number = Math.abs(delta) >= 100 || Math.abs(delta) == Math.rint(Math.abs(delta))
            ? String.format("%.0f", Math.abs(delta))
            : String.format("%.1f", Math.abs(delta));

        return (delta > 0 ? "+" : "-") + " " + name + ": " + number;
    }
}
