package dev.bobodado.acquiredutils.client;

import dev.bobodado.acquiredutils.client.pickup.RarityHighlightHandler;
import dev.bobodado.acquiredutils.client.recipe.RecipeUnlockHighlightHandler;
import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_5684;
import net.minecraft.class_8001;
import java.util.ArrayList;
import java.util.List;

public final class ContainerOverlayHandler {

    private ContainerOverlayHandler() {
    }

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof class_465<?> containerScreen)) {
                return;
            }

            ScreenEvents.afterRender(screen).register((s, graphics, mouseX, mouseY, partialTick) ->
                render(graphics, containerScreen, mouseX, mouseY)
            );
        });
    }

    private static void render(
        class_332 graphics,
        class_465<?> screen,
        int mouseX,
        int mouseY
    ) {
        class_310 mc = class_310.method_1551();
        class_1657 player = mc.field_1724;
        if (player == null) {
            return;
        }

        int leftPos = screen.field_2776;
        int topPos = screen.field_2800;

        List<class_1735> rarityHighlighted = RarityHighlightHandler.renderBackgrounds(
            graphics, screen, player, leftPos, topPos
        );
        for (class_1735 slot : rarityHighlighted) {
            renderSlotItem(graphics, slot, leftPos, topPos);
        }

        List<class_1735> recipeHighlighted = RecipeUnlockHighlightHandler.renderBackgrounds(
            graphics, screen, player, leftPos, topPos
        );
        for (class_1735 slot : recipeHighlighted) {
            renderSlotItem(graphics, slot, leftPos, topPos);
        }

        SlotLockHandler.renderOverlay(graphics, screen, leftPos, topPos);

        int tooltipLineCount = renderHoveredTooltip(graphics, screen, player, mouseX, mouseY);
        ItemComparisonHandler.render(
            graphics,
            screen,
            player,
            mouseX,
            mouseY,
            tooltipLineCount
        );
    }

    private static void renderSlotItem(
        class_332 graphics,
        class_1735 slot,
        int leftPos,
        int topPos
    ) {
        class_1799 stack = slot.method_7677();
        if (stack.method_7960()) {
            return;
        }

        int x = leftPos + slot.field_7873;
        int y = topPos + slot.field_7872;

        graphics.method_51427(stack, x, y);
        graphics.method_51431(class_310.method_1551().field_1772, stack, x, y);
    }

    private static int renderHoveredTooltip(
        class_332 graphics,
        class_465<?> screen,
        class_1657 player,
        int mouseX,
        int mouseY
    ) {
        class_1735 hovered = screen.field_2787;
        if (hovered == null || !hovered.method_7681()) {
            return 0;
        }

        class_1799 stack = hovered.method_7677();
        List<class_2561> lines = stack.method_7950(
            class_1792.class_9635.method_59528(player.method_73183()),
            player,
            class_1836.class_1837.field_41070
        );

        if (lines.isEmpty()) {
            return 0;
        }

        List<class_5684> components = new ArrayList<>(lines.size());
        for (class_2561 line : lines) {
            components.add(class_5684.method_32662(line.method_30937()));
        }

        graphics.method_51435(
            class_310.method_1551().field_1772,
            components,
            mouseX,
            mouseY,
            class_8001.field_41687,
            null
        );

        return components.size();
    }
}
