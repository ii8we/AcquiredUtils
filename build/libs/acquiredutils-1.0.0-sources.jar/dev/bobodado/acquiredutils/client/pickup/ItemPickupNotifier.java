package dev.bobodado.acquiredutils.client.pickup;

import dev.bobodado.acquiredutils.AcquiredUtils;
import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class ItemPickupNotifier {

    private static final class_2960 HUD_ID =
        class_2960.method_60655(AcquiredUtils.MOD_ID, "item_pickup_notifier");

    private static final List<PickupNotification> NOTIFICATIONS = new ArrayList<>();
    private static List<class_1799> previousInventory = null;

    private ItemPickupNotifier() {
    }

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(ItemPickupNotifier::tick);

        HudElementRegistry.attachElementAfter(
            VanillaHudElements.HOTBAR,
            HUD_ID,
            ItemPickupNotifier::render
        );
    }

    private static void tick(class_310 client) {
        if (client.field_1724 == null) {
            previousInventory = null;
            NOTIFICATIONS.clear();
            return;
        }

        List<class_1799> current = snapshot(client.field_1724.method_31548());

        if (previousInventory == null) {
            previousInventory = current;
            return;
        }

        if (AcquiredUtilsConfig.get().itemPickupNotifierEnabled && client.field_1755 == null) {
            detectGains(previousInventory, current);
        }

        previousInventory = current;
        removeExpired(System.currentTimeMillis());
    }

    private static List<class_1799> snapshot(net.minecraft.class_1661 inventory) {
        int size = inventory.method_5439();
        List<class_1799> result = new ArrayList<>(size);

        for (int i = 0; i < size; i++) {
            result.add(inventory.method_5438(i).method_7972());
        }

        return result;
    }

    private static void detectGains(List<class_1799> previous, List<class_1799> current) {
        List<class_1799> processed = new ArrayList<>();

        for (class_1799 stack : current) {
            if (stack.method_7960() || containsSame(processed, stack)) {
                continue;
            }

            int previousCount = countMatching(previous, stack);
            int currentCount = countMatching(current, stack);
            int gained = currentCount - previousCount;

            if (gained > 0) {
                ItemRarity rarity = ItemRarityDetector.detect(stack, class_310.method_1551().field_1724);
                if (rarity != null) {
                    addNotification(gained, stack, rarity);
                }
            }

            processed.add(stack);
        }
    }

    private static int countMatching(List<class_1799> stacks, class_1799 target) {
        int total = 0;
        for (class_1799 stack : stacks) {
            if (class_1799.method_31577(stack, target)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    private static boolean containsSame(List<class_1799> stacks, class_1799 target) {
        for (class_1799 stack : stacks) {
            if (class_1799.method_31577(stack, target)) return true;
        }
        return false;
    }

    private static void addNotification(int amount, class_1799 stack, ItemRarity rarity) {
        String name = stack.method_7964().getString();
        String text = amount + "x " + name;
        long expiresAt = System.currentTimeMillis() +
            (long) (AcquiredUtilsConfig.get().notificationDuration * 1000.0f);

        NOTIFICATIONS.add(new PickupNotification(text, rarity.color(), expiresAt));
        while (NOTIFICATIONS.size() > 5) {
            NOTIFICATIONS.remove(0);
        }
    }

    private static void removeExpired(long now) {
        Iterator<PickupNotification> iterator = NOTIFICATIONS.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().expiresAt() <= now) {
                iterator.remove();
            }
        }
    }

    private static void render(class_332 graphics, class_9779 tickCounter) {
        AcquiredUtilsConfig cfg = AcquiredUtilsConfig.get();
        if (!cfg.itemPickupNotifierEnabled) return;

        removeExpired(System.currentTimeMillis());
        if (NOTIFICATIONS.isEmpty()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690.field_1842) return;

        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();
        int centerX = Math.round(cfg.notificationPositionX * screenWidth);
        int startY = Math.round(cfg.notificationPositionY * screenHeight);

        int y = startY;
        for (PickupNotification notification : NOTIFICATIONS) {
            class_2561 text = class_2561.method_43470(notification.text());
            int width = client.field_1772.method_27525(text);
            int drawX;

            if (cfg.notificationPositionX < 0.5f) {
                drawX = centerX;
            } else if (cfg.notificationPositionX > 0.5f) {
                drawX = centerX - width;
            } else {
                drawX = centerX - width / 2;
            }

            graphics.method_51439(
                client.field_1772,
                text,
                drawX,
                y,
                notification.color(),
                true
            );
            y += 12;
        }
    }
}
