package dev.bobodado.acquiredutils.client.pickup;

import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_332;
import net.minecraft.class_465;

public final class RarityHighlightHandler {

    private RarityHighlightHandler() {
    }

    public static void init() {
        // Rendering is coordinated by ContainerOverlayHandler.
    }

    public static java.util.List<class_1735> renderOverlay(
        class_332 graphics,
        class_465<?> screen,
        class_1657 player,
        int leftPos,
        int topPos
    ) {
        AcquiredUtilsConfig cfg = AcquiredUtilsConfig.get();

        if (player == null || !cfg.rarityCircleEnabled) {
            return new java.util.ArrayList<>();
        }
        int radius = Math.max(3, Math.min(8, Math.round(cfg.rarityCircleSize)));
        int alpha = Math.max(0, Math.min(255, Math.round(cfg.rarityCircleOpacity * 150.0f)));
        java.util.List<class_1735> highlighted = new java.util.ArrayList<>();

        for (class_1735 slot : screen.method_17577().field_7761) {
            if (!slot.method_7682() || slot.method_7677().method_7960()) {
                continue;
            }

            ItemRarity rarity = ItemRarityDetector.detect(slot.method_7677(), player);
            if (rarity == null) {
                continue;
            }

            int slotX = leftPos + slot.field_7873;
            int slotY = topPos + slot.field_7872;

            drawRarityCircle(
                graphics,
                slotX + 8,
                slotY + 8,
                rarity.color(),
                radius,
                alpha
            );
            highlighted.add(slot);
        }

        return highlighted;
    }

    private static void drawRarityCircle(
        class_332 graphics,
        int centerX,
        int centerY,
        int color,
        int radius,
        int alpha
    ) {
        int argb = (alpha << 24) | (color & 0x00FFFFFF);

        for (int dy = -radius; dy <= radius; dy++) {
            int width = (int) Math.floor(
                Math.sqrt(radius * radius - dy * dy)
            );

            graphics.method_25294(
                centerX - width,
                centerY + dy,
                centerX + width + 1,
                centerY + dy + 1,
                argb
            );
        }
    }
}
