package dev.bobodado.acquiredutils.client.pickup;

import java.util.Locale;
import java.util.regex.Pattern;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;

public final class ItemRarityDetector {

    private static final Pattern[] RARITY_PATTERNS = {
        Pattern.compile("^COMMON(?:\\s|$)"),
        Pattern.compile("^UNCOMMON(?:\\s|$)"),
        Pattern.compile("^RARE(?:\\s|$)"),
        Pattern.compile("^EPIC(?:\\s|$)"),
        Pattern.compile("^LEGENDARY(?:\\s|$)"),
        Pattern.compile("^MYTHIC(?:\\s|$)")
    };

    private ItemRarityDetector() {
    }

    public static ItemRarity detect(class_1799 stack, class_1657 player) {
        if (stack == null || stack.method_7960() || player == null) {
            return null;
        }

        /*
         * The SMP stores rarity in the lore/tooltip text, for example:
         * "EPIC CHESTPLATE".
         *
         * The item's display-name color is intentionally NOT used here.
         * This prevents ordinary items with a colored name from being
         * incorrectly marked as a rarity item.
         *
         * Tooltip line 0 is the item's display name, so start at line 1
         * and inspect only the remaining tooltip/lore lines.
         */
        var tooltipLines = stack.method_7950(
            class_1792.class_9635.method_59528(player.method_73183()),
            player,
            class_1836.class_1837.field_41070
        );

        for (int i = 1; i < tooltipLines.size(); i++) {
            String line = tooltipLines.get(i).getString().trim();
            ItemRarity rarity = detectLoreLine(line);

            if (rarity != null) {
                return rarity;
            }
        }

        return null;
    }

    private static ItemRarity detectLoreLine(String text) {
        String upper = text.toUpperCase(Locale.ROOT);

        for (int i = 0; i < RARITY_PATTERNS.length; i++) {
            if (RARITY_PATTERNS[i].matcher(upper).find()) {
                return ItemRarity.values()[i];
            }
        }

        return null;
    }
}
