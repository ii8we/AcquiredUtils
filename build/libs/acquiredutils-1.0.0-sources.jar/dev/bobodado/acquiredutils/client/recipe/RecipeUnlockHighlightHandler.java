package dev.bobodado.acquiredutils.client.recipe;

import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_465;

public final class RecipeUnlockHighlightHandler {

    private static final String RECIPES_TITLE_PREFIX = "Recipes -";
    private static final int HIGHLIGHT_COLOR = 0xFF39D66F;
    private static final int HIGHLIGHT_BORDER_COLOR = 0xFF7CFF9B;

    private RecipeUnlockHighlightHandler() {
    }

    public static List<class_1735> renderBackgrounds(
        class_332 graphics,
        class_465<?> screen,
        class_1657 player,
        int leftPos,
        int topPos
    ) {
        List<class_1735> highlighted = new ArrayList<>();

        AcquiredUtilsConfig cfg = AcquiredUtilsConfig.get();
        if (!cfg.recipeUnlockHighlightEnabled || player == null || !isRecipeVault(screen)) {
            return highlighted;
        }

        for (class_1735 slot : screen.method_17577().field_7761) {
            // Only highlight slots belonging to the recipe vault itself.
            // Player inventory slots are part of the same menu, so explicitly exclude them.
            if (slot.field_7871 == player.method_31548()) {
                continue;
            }

            class_1799 stack = slot.method_7677();
            if (!slot.method_7682() || stack.method_7960() || !isRecipeUnlocked(stack, player)) {
                continue;
            }

            int x = leftPos + slot.field_7873;
            int y = topPos + slot.field_7872;

            drawUnlockedTriangle(graphics, x, y);
            highlighted.add(slot);
        }

        return highlighted;
    }

    private static void drawUnlockedTriangle(
        class_332 graphics,
        int x,
        int y
    ) {
        // Full 16x16 square overlay: exactly one vanilla slot.
        graphics.method_25294(
            x,
            y,
            x + 16,
            y + 16,
            0x3D39D66F
        );

        graphics.method_73198(
            x,
            y,
            16,
            16,
            0xB87CFF9B
        );
    }

    private static boolean isRecipeVault(class_465<?> screen) {
        String title = screen.method_25440().getString();
        return title.strip().toLowerCase(java.util.Locale.ROOT)
            .startsWith(RECIPES_TITLE_PREFIX.toLowerCase(java.util.Locale.ROOT));
    }

    private static boolean isRecipeUnlocked(class_1799 stack, class_1657 player) {
        List<class_2561> tooltipLines = stack.method_7950(
            class_1792.class_9635.method_59528(player.method_73183()),
            player,
            class_1836.class_1837.field_41070
        );

        for (class_2561 line : tooltipLines) {
            String text = line.getString().stripLeading();
            if (text.contains("✓") || text.contains("✔")) {
                return true;
            }
        }

        return false;
    }
}
