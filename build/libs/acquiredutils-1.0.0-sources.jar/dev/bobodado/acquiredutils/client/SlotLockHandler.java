package dev.bobodado.acquiredutils.client;

import dev.bobodado.acquiredutils.AcquiredUtils;
import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.class_1735;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_465;

public final class SlotLockHandler {

    private static final class_2960 LOCK_TEXTURE =
        class_2960.method_60655(
            AcquiredUtils.MOD_ID,
            "textures/gui/lock.png"
        );

    private SlotLockHandler() {
    }

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof class_465<?> containerScreen)) {
                return;
            }

            ScreenMouseEvents.allowMouseClick(screen).register((s, event) -> {
                if (!AcquiredUtilsConfig.get().slotLockEnabled) return true;

                class_1735 hovered = containerScreen.field_2787;
                if (hovered == null || !isPlayerInventorySlot(hovered) || !hovered.method_7682()) {
                    return true;
                }

                return !isLocked(hovered.method_34266());
            });

            ScreenKeyboardEvents.allowKeyPress(screen).register((s, event) -> {
                if (!AcquiredUtilsConfig.get().slotLockEnabled) return true;

                int keyCode = class_3675.method_15985(event).method_1444();
                if (keyCode < 0) return true;
                class_315 options = class_310.method_1551().field_1690;

                if (keyCode == AcquiredUtilsConfig.get().slotLockKey && keyCode >= 0) {
                    toggleHoveredSlot(containerScreen);
                    return false;
                }

                class_1735 hovered = containerScreen.field_2787;
                if (hovered == null || !isPlayerInventorySlot(hovered) || !hovered.method_7682()) {
                    return true;
                }

                int hoveredSlot = hovered.method_34266();

                if (options.field_1869.method_1417(event)) {
                    return !isLocked(hoveredSlot);
                }

                if (options.field_1831.method_1417(event)) {
                    return !isLocked(hoveredSlot) && !isLocked(40);
                }

                for (int i = 0; i < 9; i++) {
                    if (options.field_1852[i].method_1417(event)) {
                        return !isLocked(hoveredSlot) && !isLocked(i);
                    }
                }

                return true;
            });
        });

        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            if (!AcquiredUtilsConfig.get().slotLockEnabled) return;
            if (client.field_1724 == null || client.field_1755 != null) return;

            int selectedSlot = client.field_1724.method_31548().method_67532();
            if (!isLocked(selectedSlot)) return;

            class_315 options = client.field_1690;
            options.field_1869.method_1436();
            options.field_1831.method_1436();
        });
    }

    public static void renderOverlay(
        class_332 graphics,
        class_465<?> screen,
        int leftPos,
        int topPos
    ) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || !AcquiredUtilsConfig.get().slotLockEnabled) return;

        for (class_1735 slot : screen.method_17577().field_7761) {
            if (slot.field_7871 == mc.field_1724.method_31548()
                && slot.method_7682()
                && isLocked(slot.method_34266())) {

                drawPadlock(
                    graphics,
                    leftPos + slot.field_7873,
                    topPos + slot.field_7872
                );
            }
        }
    }

    private static void toggleHoveredSlot(class_465<?> screen) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        class_1735 hovered = screen.field_2787;
        if (hovered == null || !isPlayerInventorySlot(hovered) || !hovered.method_7682()) return;

        int idx = hovered.method_34266();
        java.util.Set<Integer> locked = AcquiredUtilsConfig.get().lockedSlots;

        if (idx < 0 || idx > 40) return;

        if (locked.contains(idx)) {
            locked.remove(idx);
        } else {
            locked.add(idx);
        }

        AcquiredUtilsConfig.save();
        AcquiredUtils.LOGGER.info(
            "[AcquiredUtils] Slot {} {}",
            idx,
            locked.contains(idx) ? "locked" : "unlocked"
        );
    }

    private static boolean isPlayerInventorySlot(class_1735 slot) {
        class_310 mc = class_310.method_1551();
        return mc.field_1724 != null && slot.field_7871 == mc.field_1724.method_31548();
    }

    public static boolean isLocked(int containerSlotIndex) {
        AcquiredUtilsConfig cfg = AcquiredUtilsConfig.get();

        if (cfg.lockedSlots.contains(containerSlotIndex)) {
            return true;
        }

        if (containerSlotIndex >= 0 && containerSlotIndex <= 8 && cfg.autoProtectHotbar) {
            return true;
        }

        if (containerSlotIndex >= 9 && containerSlotIndex <= 35 && cfg.autoProtectInventory) {
            return true;
        }

        if (containerSlotIndex >= 36 && containerSlotIndex <= 39 && cfg.autoProtectArmor) {
            return true;
        }

        return containerSlotIndex == 40 && cfg.autoProtectOffhand;
    }



    private static void drawPadlock(class_332 graphics, int x, int y) {
        graphics.method_25290(
            net.minecraft.class_10799.field_56883,
            LOCK_TEXTURE,
            x,
            y,
            0.0f,
            0.0f,
            16,
            16,
            16,
            16
        );
    }
}
