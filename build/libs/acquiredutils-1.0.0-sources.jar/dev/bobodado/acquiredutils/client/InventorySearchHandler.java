package dev.bobodado.acquiredutils.client;

import dev.bobodado.acquiredutils.config.AcquiredUtilsConfig;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import java.util.Locale;

public final class InventorySearchHandler {

    private static String query = "";
    private static boolean searching = false;

    private InventorySearchHandler() {
    }

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof class_465<?> containerScreen)) {
                return;
            }

            searching = false;
            query = "";

            ScreenKeyboardEvents.allowKeyPress(screen).register((s, event) -> {
                int keyCode = class_3675.method_15985(event).method_1444();
                AcquiredUtilsConfig cfg = AcquiredUtilsConfig.get();

                if (!searching && keyCode == cfg.inventorySearchKey) {
                    searching = true;
                    query = "";
                    return false;
                }

                if (!searching) {
                    return true;
                }

                if (keyCode == class_3675.field_31958) {
                    searching = false;
                    query = "";
                    return false;
                }

                if (keyCode == class_3675.field_31986) {
                    if (!query.isEmpty()) {
                        query = query.substring(0, query.length() - 1);
                    }
                    return false;
                }

                char typed = toCharacter(keyCode);
                if (typed != 0 && query.length() < 32) {
                    query += typed;
                    return false;
                }

                return true;
            });

            ScreenEvents.afterRender(screen).register(
                (s, graphics, mouseX, mouseY, partialTick) ->
                    render(graphics, containerScreen)
            );
        });
    }

    private static void render(
        class_332 graphics,
        class_465<?> screen
    ) {
        class_310 mc = class_310.method_1551();
        class_1657 player = mc.field_1724;

        if (player == null || !searching) {
            return;
        }

        int x = screen.field_2776;
        int y = screen.field_2800 - 22;

        int w = 170;
        int h = 18;

        graphics.method_25294(x, y, x + w, y + h, 0xE60B0712);
        graphics.method_73198(x, y, w, h, 0xFF7C5C9E);

        String text = query.isEmpty() ? "Search inventory..." : "Search: " + query;
        graphics.method_51439(
            mc.field_1772,
            class_2561.method_43470(text),
            x + 5,
            y + 5,
            query.isEmpty() ? 0xFFAA9FB0 : 0xFFF2EAF7,
            false
        );

        String normalized = query.toLowerCase(Locale.ROOT);

        for (class_1735 slot : screen.method_17577().field_7761) {
            if (!slot.method_7682() || !slot.method_7681() || normalized.isEmpty()) {
                continue;
            }

            class_1799 stack = slot.method_7677();
            if (!matches(stack, player, normalized)) {
                continue;
            }

            int sx = screen.field_2776 + slot.field_7873;
            int sy = screen.field_2800 + slot.field_7872;

            graphics.method_25294(sx, sy, sx + 16, sy + 16, 0x3D9A6CFF);
            graphics.method_73198(sx, sy, 16, 16, 0xFFBFA4FF);
        }
    }

    private static boolean matches(class_1799 stack, class_1657 player, String normalized) {
        if (stack.method_7964().getString().toLowerCase(Locale.ROOT).contains(normalized)) {
            return true;
        }

        for (class_2561 line : stack.method_7950(
            class_1792.class_9635.method_59528(player.method_73183()), player, class_1836.class_1837.field_41070)) {
            if (line.getString().toLowerCase(Locale.ROOT).contains(normalized)) {
                return true;
            }
        }

        return false;
    }

    private static char toCharacter(int keyCode) {
        if (keyCode >= class_3675.field_32015 && keyCode <= class_3675.field_31915) {
            return (char) ('a' + (keyCode - class_3675.field_32015));
        }

        if (keyCode >= class_3675.field_31940 && keyCode <= class_3675.field_32014) {
            return (char) ('0' + (keyCode - class_3675.field_31940));
        }

        if (keyCode == class_3675.field_31947) {
            return ' ';
        }

        if (keyCode == class_3675.field_31941) {
            return '-';
        }

        return 0;
    }
}
